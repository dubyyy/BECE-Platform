import { redirect } from "next/navigation";

export default function SignIn() {
  redirect("/zuwa2");
}
