-- AlterTable
ALTER TABLE "Result" ALTER COLUMN "institutionCd" DROP NOT NULL;
