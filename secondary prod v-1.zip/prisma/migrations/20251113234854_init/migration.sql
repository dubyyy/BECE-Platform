-- AlterTable
ALTER TABLE "Result" ALTER COLUMN "userId" DROP NOT NULL;
