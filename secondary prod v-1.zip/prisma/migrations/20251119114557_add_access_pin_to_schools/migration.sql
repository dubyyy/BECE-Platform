-- AlterTable
ALTER TABLE "School" ADD COLUMN     "accessPin" TEXT;
